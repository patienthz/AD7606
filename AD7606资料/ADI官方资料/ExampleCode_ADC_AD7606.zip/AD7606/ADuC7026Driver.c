/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia) 

 Date : 2012-01-04

 File name : ADuC7026Driver.c

 Description :  Implement basic driver of ADuC7026

 Hardware plateform : ADuC7026_DEMO_V1.2  	
********************************************************************************/

#include "ADuC7026.h"
#include "ADuC7026Driver.h"
#include "stdio.h"

#pragma import(__use_no_semihosting_swi)


void ADuC7026InitializePll(void)
{	
	//41.78MHz
	POWKEY1 = 0x01;				//Start PLL setting,changeless
	POWCON=0x00;
	POWKEY2 = 0xF4;				//Finish PLL setting,changeless
}

void ADuC7026InitializeUart(void)
{
	// Setup tx & rx pins on SPM 0 and SPM 1
	GP1CON |= 0x11;
 
	//Initiate the UART Port to 115200bps
	// CD = 0 !		 
	COMCON0 = 0x80;					// Setting DLAB
   	COMDIV0 = 0x0B;					// Setting DIV0 and DIV1 to DL calculated
	COMDIV1 = 0x00;

   	COMCON0 = 0x07;					// Clearing DLAB
	// fractional divider
  	COMDIV2 = 0x883E;			  	// M=1
									// N=01101010101  =853
									// M+N/2048	 =1.4165
									//41.78MHz/(16*2*2^CD*DL*(M+N/2048))	 //CD=0  DL=0B=11
									//115.2Kbps  M+N/2048 =1.0303	M=1, N=	 62=0x3EH=000 0011 1110
									//comdiv2=0x883E
		
}


void ADuC7026InitializeInterrupt(void)
{
	// disable all FIQs and IRQs
	FIQEN=0x00;
	IRQEN=0x00;
}

void ADuC7026Initialization(void)
{
	ADuC7026InitializePll();
	ADuC7026InitializeInterrupt();
	ADuC7026InitializeUart();

}

/* GPIO Control */
void ADuC7026SwitchBit(unsigned char GPIONum)
{
	unsigned long int Temp;

	Temp=1<<(GPIONum&0x0F);

	switch(GPIONum>>4)
	{
		case	0:
			GP0DAT|=(Temp<<24);
			GP0DAT^=(Temp<<16);
			break;
		case	1:
			GP1DAT|=(Temp<<24);
			GP1DAT^=(Temp<<16);
			break;
		case	2:
			GP2DAT|=(Temp<<24);
			GP2DAT^=(Temp<<16);
			break;
		case	3:
			GP3DAT|=(Temp<<24);
			GP3DAT^=(Temp<<16);
			break;
		case	4:
			GP4DAT|=(Temp<<24);
			GP4DAT^=(Temp<<16);
			break;
	}	
}

unsigned char ADuC7026InputBit(unsigned char GPIONum)
{
	unsigned long int Temp;
	unsigned char Data;

	Temp=0xFFFFFFFF-(1<<((GPIONum&0x0F)+24));

	switch(GPIONum>>4)
	{
		case	0:
			GP0DAT&=Temp;
			Data=GP0DAT;		
			break;
		case	1:
			GP1DAT&=Temp;
			Data=GP1DAT;
			break;
		case	2:
			GP2DAT&=Temp;
			Data=GP2DAT;
			break;
		case	3:
			GP3DAT&=Temp;
			Data=GP3DAT;
			break;
		case	4:
			GP4DAT&=Temp;
			Data=GP4DAT;
			break;
	}
	if((Data&(1<<(GPIONum&0x0F)))==(1<<(GPIONum&0x0F)))
	{
		Data=1;
	}
	else
	{
		Data=0;
	}

	return Data;
}

void ADuC7026OutputBit(unsigned char GPIONum, unsigned char Data)
{
	unsigned long int Temp;

	Temp=1<<(GPIONum&0x0F);



	switch(GPIONum>>4)
	{
		case	0:
			GP0DAT|=(Temp<<24);
			if(Data==0)
			{
				GP0CLR=(Temp<<16);
			}
			else
			{
				GP0SET=(Temp<<16);	
			}
			break;
		case	1:
			GP1DAT|=(Temp<<24);
			if(Data==0)
			{
				GP1CLR=(Temp<<16);
			}
			else
			{
				GP1SET=(Temp<<16);	
			}
			break;
		case	2:
			GP2DAT|=(Temp<<24);
			if(Data==0)
			{
				GP2CLR=(Temp<<16);
			}
			else
			{
				GP2SET=(Temp<<16);	
			}
			break;
		case	3:
			GP3DAT|=(Temp<<24);
			if(Data==0)
			{
				GP3CLR=(Temp<<16);
			}
			else
			{
				GP3SET=(Temp<<16);	
			}
			break;
		case	4:
			GP4DAT|=(Temp<<24);
			if(Data==0)
			{
				GP4CLR=(Temp<<16);
			}
			else
			{
				GP4SET=(Temp<<16);	
			}
			break;
	}
}

void ADuC7026WritePort(unsigned char PortNum, unsigned char Data)
{	  
	unsigned long int Temp1, Temp2;

	Temp2 = Data;


	switch(PortNum)
	{
		case	0:
			Temp1 = GP0DAT|0xFF000000;
			Temp1 = Temp1&0xFF00FFFF;
			GP0DAT =Temp1|(Temp2<<16);		
			break;
		case	1:
			Temp1 = GP1DAT|0xFF000000;
			Temp1 = Temp1&0xFF00FFFF;
			GP1DAT =Temp1|(Temp2<<16);
			break;
		case	2:
			Temp1 = GP2DAT|0xFF000000;
			Temp1 = Temp1&0xFF00FFFF;
			GP2DAT =Temp1|(Temp2<<16);
			break;
		case	3:
			Temp1 = GP3DAT|0xFF000000;
			Temp1 = Temp1&0xFF00FFFF;
			GP3DAT =Temp1|(Temp2<<16);;
			break;
		case	4:
			Temp1 = GP4DAT|0xFF000000;
			Temp1 = Temp1&0xFF00FFFF;
			GP4DAT =Temp1|(Temp2<<16);
			break;
	}

}

unsigned char ADuC7026ReadPort(unsigned char PortNum)
{
	unsigned char Data;

	switch(PortNum)
	{
		case	0:
			GP0DAT&=0x00FFFFFF;
			Data=GP0DAT;		
			break;
		case	1:
			GP1DAT&=0x00FFFFFF;
			Data=GP1DAT;
			break;
		case	2:
			GP2DAT&=0x00FFFFFF;
			Data=GP2DAT;
			break;
		case	3:
			GP3DAT&=0x00FFFFFF;
			Data=GP3DAT;
			break;
		case	4:
			GP4DAT&=0x00FFFFFF;
			Data=GP4DAT;
			break;
	}

	return Data;
}


/* GPIO Control */


// delay for Time*1ms, at 41.78MHz CLK.		41.78M / 256 / 163 = 1K
void ADuC7026DelayMs( unsigned int TimeMs)		
{								 
	unsigned int i;				 

	for(i=0; i<TimeMs; i++)
	{	
		T1LD = 163;			// 163 Counter Value,1ms
		T1CON = 0xC8;		// Enabled, Non-periodic,Binary and CLK/256
		while(T1VAL>1) {}
		T1CON = 0x48;		// Disabled, Non-periodic,Binary and CLK/256
	}	
}

// delay for Time*1us, at 41.78MHz CLK.		41.78M / 1 / 42 = 1M
void ADuC7026DelayUs( unsigned int TimeUs)		
{								 
	unsigned int i;				 

	for(i=0; i<TimeUs; i++)
	{	
		T1LD = 42;			// 42 Counter Value,1us
		T1CON = 0xC0;		// Enabled, Non-periodic,Binary and CLK/1
		while(T1VAL>1) {}
		T1CON = 0x40;		// Disabled, Non-periodic,Binary and CLK/1
	}	
}

/*    Function Pointers for Interrupts  */
// Copied from irq_arm.c in Keil uV4, required 
tyVctHndlr    IRQ     = (tyVctHndlr)0x0;
tyVctHndlr    SWI     = (tyVctHndlr)0x0;
tyVctHndlr    FIQ     = (tyVctHndlr)0x0;
tyVctHndlr    UNDEF   = (tyVctHndlr)0x0;
tyVctHndlr    PABORT  = (tyVctHndlr)0x0;
tyVctHndlr    DABORT  = (tyVctHndlr)0x0;

void	IRQ_Handler   (void) __irq;
void	SWI_Handler   (void) __irq;
void	FIQ_Handler   (void) __irq;
void	Undef_Handler (void) __irq;
void	PAbt_Handler  (void) __irq;
void	DAbt_Handler  (void) __irq;

void	IRQ_Handler(void) __irq
{
	if ( *IRQ !=0x00)
	{
		IRQ();
	}
}

void	FIQ_Handler(void) __irq
{
	if ( *FIQ !=0x00)
	{
		FIQ();
	}
}

void	SWI_Handler(void) __irq
{
	if ( *SWI !=0x00)
	{
		SWI();
	}
}

void	Undef_Handler(void)__irq 
{
	if ( *UNDEF !=0x00)
	{
		UNDEF();
	}
}

void	PAbt_Handler(void) __irq
{
	if ( *PABORT !=0x00)
	{
		PABORT();
	}
}

void	DAbt_Handler(void) __irq
{
	if ( *DABORT !=0x00)
	{
		DABORT();
	}
}
/*    Function Pointers for Interrupts  */

/*    Rewrite the serial port function  */
/* 	  To use the pfrintf() in ADuC702x in Keil UV4, the sendchar() must be rewrite */
int sendchar (int ch)  {                 
      while(!(0x020==(COMSTA0 & 0x020)))	{}
 
 	COMTX = ch;

	while(!(0x020==(COMSTA0 & 0x020)))	{}

	return ch;
}

struct __FILE { int handle; /* Add whatever you need here */ };
FILE __stdout;
FILE __stdin;
FILE __stderr;

int fputc (int ch, FILE *f) {
  return (sendchar(ch));
}

int fgetc (FILE *fp)  {
  return (0);
}


int fclose (FILE* f) {
  return 0;
}

int ferror(FILE *f) {
  /* Your implementation of ferror */
  return EOF;
}

int fseek (FILE *fp, long nPos, int nMode)  {
  return (0);
}

int fflush (FILE *pStream)  {
  return (0);
}

void _ttywrch (int ch) {
  sendchar(ch);
}

void _sys_exit (int return_code) {
label:  goto label;  /* endless loop */
}
/*    Rewrite the serial port function  */
