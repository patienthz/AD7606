/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia) 

 Date : 2012-01-04

 File name : AD7606.h

 Description : test the serial port operation of AD7606

 Hardware plateform : ADuC7026_DEMO_V1.2 + EVAL-AD7606EDZ_Rev.A1  	
********************************************************************************/

#ifndef AD7606_DRIVER_H
#define AD7606_DRIVER_H

void AD7606Initialization(void);
void AD7606Reset(void);
void AD7606ReadOneSample(unsigned short int *DoutA, unsigned short int *DoutB, unsigned char Channels);

#endif
