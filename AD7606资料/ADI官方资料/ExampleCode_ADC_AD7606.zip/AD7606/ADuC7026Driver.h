/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia) 

 Date : 2012-01-04

 File name : ADuC7026Driver.h

 Description : Implement basic driver of ADuC7026

 Hardware plateform : ADuC7026_DEMO_V1.2 	
********************************************************************************/

#ifndef ADUC7026_DRIVER_H
#define ADUC7026_DRIVER_H

#define AD7606_CNVST	0x30	// pin A17 = P3.0
#define AD7606_CS		0x25	// pin C10 = P2.5
#define	AD7606_RESET	0x24	// pin B1  = P2.4	
#define	AD7606_SCLK		0x32	// pin A9  = P3.2
#define AD7606_DOUTA	0x34	// pin C5  = P3.4
#define AD7606_DOUTB	0x33	// pin C13 = P3.3
#define AD7606_BUSY		0x31	// pin C17 = P3.1

void ADuC7026Initialization(void);
int sendchar (int ch);

void ADuC7026DelayMs( unsigned int TimeMs);
void ADuC7026DelayUs( unsigned int TimeUs);

unsigned char ADuC7026ReadPort(unsigned char PortNum);
void ADuC7026WritePort(unsigned char PortNum, unsigned char Data);
unsigned char ADuC7026InputBit(unsigned char GPIONum);
void ADuC7026OutputBit(unsigned char GPIONum, unsigned char Data);
void ADuC7026SwitchBit(unsigned char GPIONum);

#endif





