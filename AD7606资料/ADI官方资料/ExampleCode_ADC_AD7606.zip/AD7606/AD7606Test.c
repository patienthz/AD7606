/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia) 

 Date : 2012-01-04

 File name : AD7606Test.c

 Description : test the serial port operation of AD7606

 Hardware plateform : ADuC7026_DEMO_V1.2 + EVAL-AD7606EDZ_Rev.A1  	
********************************************************************************/

#include "ADuC7026.h"
#include "ADuC7026Driver.h"
#include "AD7606.h"
#include "stdio.h"

unsigned short int DataA[8];
unsigned short int DataB[8];
unsigned short int SampleCount;
unsigned char ChannelCount;
unsigned short int i, j;
int main(void)
{
	
	ADuC7026Initialization();

	AD7606Initialization();

	AD7606Reset();

	SampleCount=100;
	ChannelCount=8;

	/* test functions */ 

	printf("\r\nRead AD7606 via serial port.\r\n\r\n");

	for(i=0; i<SampleCount; i++)
	{
		printf("Sample%d\r\n", i);

		AD7606ReadOneSample(DataA, DataB, ChannelCount);

		for(j=0; j<ChannelCount; j++)
		{
			printf("DoutA[%d] = %04x , DoutB[%d] = %04x .\r\n", j, DataA[j], j, DataB[j]);
		}
		printf("\r\n");
	}

	

	/* test functions */ 

	while(1){;}		/* wait, endless loop */
}

