/********************************************************************************
 Author : CAC (CustomerApplications Center, Asia) 

 Date : 2012-01-04

 File name : AD7606.c

 Description : test the serial port operation of AD7606

 Hardware plateform : ADuC7026_DEMO_V1.2 + EVAL-AD7606EDZ_Rev.A1  	
********************************************************************************/

#include "ADuC7026.h"
#include "ADuC7026Driver.h"
#include "AD7606.h"



void AD7606Initialization(void)
{
	ADuC7026DelayMs(1);
	ADuC7026OutputBit(AD7606_RESET, 0);
	ADuC7026OutputBit(AD7606_CS, 1);
	ADuC7026OutputBit(AD7606_CNVST, 1);
	ADuC7026OutputBit(AD7606_SCLK, 1);
	ADuC7026InputBit(AD7606_DOUTA);
	ADuC7026InputBit(AD7606_DOUTB);
	ADuC7026InputBit(AD7606_BUSY);
	ADuC7026DelayMs(1);
}

void AD7606Reset(void)
{
	ADuC7026OutputBit(AD7606_RESET, 1);
	ADuC7026DelayUs(1);
	ADuC7026OutputBit(AD7606_RESET, 0);
	ADuC7026DelayUs(1);
}

void AD7606ReadOneSample(unsigned short int *DoutA, unsigned short int *DoutB, unsigned char Channels)
{
	unsigned char j, k;
	unsigned short int TempA, TempB;

	unsigned char Busy;


	ADuC7026OutputBit(AD7606_CNVST, 0);
	ADuC7026DelayUs(1);
	ADuC7026OutputBit(AD7606_CNVST, 1);
	ADuC7026DelayUs(1);

	Busy=ADuC7026InputBit(AD7606_BUSY);

	while(Busy==1)
	{
		ADuC7026DelayUs(1);
		Busy=ADuC7026InputBit(AD7606_BUSY);
	}

	ADuC7026OutputBit(AD7606_CS, 0);

	for(j=0; j<Channels; j++)
	{
		TempA=0;
		TempB=0;

		for(k=0; k<16; k++)
		{
			ADuC7026OutputBit(AD7606_SCLK, 0);

			TempA=(TempA<<1) + ADuC7026InputBit(AD7606_DOUTA);
			TempB=(TempB<<1) + ADuC7026InputBit(AD7606_DOUTB);

			ADuC7026OutputBit(AD7606_SCLK, 1);
		}
		
		DoutA[j]=TempA;
		DoutB[j]=TempB;
	}

	ADuC7026OutputBit(AD7606_CS, 1);
}
